﻿using UnityEngine;
using System.Collections;

public class Destroythis : MonoBehaviour {

	// Use this for initialization
	void Start () {
       Destroy(gameObject, 3f);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
