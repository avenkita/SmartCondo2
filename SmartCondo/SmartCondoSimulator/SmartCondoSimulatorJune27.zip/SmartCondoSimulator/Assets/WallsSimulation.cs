﻿/*using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class WallsSimulation : MonoBehaviour
{

    GameObject mycube = Resources.Load("Cube1") as GameObject;







    const int JointsNumber = 25;
    bool active = false;
    int actividad = 0;
    public Transform SpineBase, SpineMid, Neck, Head, ShoulderLeft, ElbowLeft, WristLeft, HandLeft, ShoulderRight, ElbowRight, WristRight, HandRight, HipLeft, KneeLeft, AnkleLeft, FootLeft, HipRight, KneeRight, AnkleRight, FootRight, SpineShoulder, HandTipLeft, ThumbLeft, HandTipRight, ThumbRight;
    public Transform AvatarSkeleton;
    public struct joint1
    {
        public Transform Joint;
        public float initialX;
        public float initialY;
        public float initialZ;
        public float FinalX;
        public float FinalY;
        public float FinalZ;
        public float DeltaX;
        public float DeltaY;
        public float DeltaZ;
    };

    public joint1[] skeleton = new joint1[JointsNumber];

    public string[] JointsNames = new string[] { "SpineBase", "SpineMid", "Neck", "Head", "ShoulderLeft", "ElbowLeft", "WristLeft", "HandLeft", "ShoulderRight", "ElbowRight", "WristRight", "HandRight", "HipLeft", "KneeLeft", "AnkleLeft", "FootLeft", "HipRight", "KneeRight", "AnkleRight", "FootRight", "SpineShoulder", "HandTipLeft", "ThumbLeft", "HandTipRight", "ThumbRight" };
    public decimal AxisM;
    public float[,] SkeletonInitial = new float[JointsNumber, 3];

    int steps;

    List<Joint> jointsXML = new List<Joint>();
    List<Animation> animationXML = new List<Animation>();

    #region CAMPO
    void animar(List<Animation> animationXML, List<Joint> JointsXML)
    {

    }

    void Awake()
    {
        #region Initialize
        skeleton[0].Joint = SpineBase; SkeletonInitial[0, 0] = 0f; SkeletonInitial[0, 1] = 0f; SkeletonInitial[0, 2] = 355.8804f;//00 JointSpineBase
        skeleton[1].Joint = SpineMid; SkeletonInitial[1, 0] = 0.0f; SkeletonInitial[1, 1] = 0.0f; SkeletonInitial[1, 2] = 7.4783f;  //01 JointSpineMid
        skeleton[2].Joint = Neck; SkeletonInitial[2, 0] = 0.0f; SkeletonInitial[2, 1] = 0.0f; SkeletonInitial[2, 2] = 347.4643f;//02 JointNeck
        skeleton[3].Joint = Head; SkeletonInitial[3, 0] = 0.0081f; SkeletonInitial[3, 1] = 0.0014f; SkeletonInitial[3, 2] = 19.55635f;//03 JointHead
        skeleton[4].Joint = ShoulderLeft; SkeletonInitial[4, 0] = 286.4365f; SkeletonInitial[4, 1] = 270.1477f; SkeletonInitial[4, 2] = 181.2551f;//04 JointShoulderLeft
        skeleton[5].Joint = ElbowLeft; SkeletonInitial[5, 0] = 0.0637f; SkeletonInitial[5, 1] = 0.0f; SkeletonInitial[5, 2] = 11.1367f; //05 JointElbowLeft
        skeleton[6].Joint = WristLeft; SkeletonInitial[6, 0] = 0.0f; SkeletonInitial[6, 1] = 0.000f; SkeletonInitial[6, 2] = 348.9652f;//06 JointWristLeft
        skeleton[7].Joint = HandLeft; SkeletonInitial[7, 0] = 5.3582f; SkeletonInitial[7, 1] = 90.1578f; SkeletonInitial[7, 2] = 357.5286f;//07 JointHandLeft
        skeleton[8].Joint = ShoulderRight; SkeletonInitial[8, 0] = -76.9907f; SkeletonInitial[8, 1] = -89.7947f; SkeletonInitial[8, 2] = -1.7447f; //08 JointShoulderRight
        skeleton[9].Joint = ElbowRight; SkeletonInitial[9, 0] = 0.0638f; SkeletonInitial[9, 1] = 359.675f; SkeletonInitial[9, 2] = 11.1367f; //09 JointElbowRight
        skeleton[10].Joint = WristRight; SkeletonInitial[10, 0] = 53.0517f; SkeletonInitial[10, 1] = 92.2377f; SkeletonInitial[10, 2] = 104.6375f;//10 JointWristRight
        skeleton[11].Joint = HandRight; SkeletonInitial[11, 0] = 351.6493f; SkeletonInitial[11, 1] = 226.7722f; SkeletonInitial[11, 2] = 93.9152f; //11 JointHandRight
        skeleton[12].Joint = HipLeft; SkeletonInitial[12, 0] = 359.328f; SkeletonInitial[12, 1] = 90f; SkeletonInitial[12, 2] = 84.6076f; //12 JointHipLeft
        skeleton[13].Joint = KneeLeft; SkeletonInitial[13, 0] = 0.0f; SkeletonInitial[13, 1] = 0.0f; SkeletonInitial[13, 2] = 3.3913f;  //13 JointKneeLeft
        skeleton[14].Joint = AnkleLeft; SkeletonInitial[14, 0] = 0.0f; SkeletonInitial[14, 1] = 0.0f; SkeletonInitial[14, 2] = 359.4911f;//14 JointAnkleLeft
        skeleton[15].Joint = FootLeft; SkeletonInitial[15, 0] = 0.0f; SkeletonInitial[15, 1] = 0.0f; SkeletonInitial[15, 2] = 271.828f; //15 JointFootLeft
        skeleton[16].Joint = HipRight; SkeletonInitial[16, 0] = 359.328f; SkeletonInitial[16, 1] = 90.0f; SkeletonInitial[16, 2] = 85.2896f; //16 JointHipRight
        skeleton[17].Joint = KneeRight; SkeletonInitial[17, 0] = 0.0f; SkeletonInitial[17, 1] = 0.0f; SkeletonInitial[17, 2] = 358.9486f;//17 JointKneeRight
        skeleton[18].Joint = AnkleRight; SkeletonInitial[18, 0] = 0.0f; SkeletonInitial[18, 1] = 0.0f; SkeletonInitial[18, 2] = 359.4911f;//18 JointAnkleRight
        skeleton[19].Joint = FootRight; SkeletonInitial[19, 0] = 0.0f; SkeletonInitial[19, 1] = 0.0f; SkeletonInitial[19, 2] = 271.828f; //19 JointFootRight
        skeleton[20].Joint = SpineShoulder; SkeletonInitial[20, 0] = 0.0f; SkeletonInitial[20, 1] = 0.0f; SkeletonInitial[20, 2] = 0.0f;     //20 JointSpineShoulder
        skeleton[21].Joint = HandTipLeft; SkeletonInitial[21, 0] = 0.0f; SkeletonInitial[21, 1] = 0.0f; SkeletonInitial[21, 2] = 0.0f;     //21 JointHandTipLeft
        skeleton[22].Joint = ThumbLeft; SkeletonInitial[22, 0] = 0.6823f; SkeletonInitial[22, 1] = 359.4518f; SkeletonInitial[22, 2] = 28.7267f; //22 JointThumbLeft
        skeleton[23].Joint = HandTipRight; SkeletonInitial[23, 0] = 359.9135f; SkeletonInitial[23, 1] = 359.9937f; SkeletonInitial[23, 2] = 350.9228f;//23 JointHandTipRight
        skeleton[24].Joint = ThumbRight; SkeletonInitial[24, 0] = 282.0912f; SkeletonInitial[24, 1] = 96.41859f; SkeletonInitial[24, 2] = 244.5103f;//24 JointThumbRight

        for (int i = 0; i < JointsNumber; i++)//Initialize values of the animation joints
        {
            skeleton[i].initialX = 0;
            skeleton[i].initialY = 0;
            skeleton[i].initialZ = 0;
            skeleton[i].DeltaX = 0.0f;
            skeleton[i].DeltaY = 0.0f;
            skeleton[i].DeltaZ = 0.0f;
            MoveJointAbsolute(skeleton[i].Joint, SkeletonInitial[i, 0],
                                                 SkeletonInitial[i, 1],
                                                 SkeletonInitial[i, 2]);
        }
        #endregion
        animationXML = ReadPosture.getAnimation();
        animationXML = discretizacionAnimation(animationXML);
        jointsXML = ReadPosture.getJoints();
        jointsXML = discretizacion(jointsXML);
        anima();

    }

    #endregion

    void anima()
    {
        animacion(0);
    }



    void animacion(int Activity)
    {
        active = true;
        steps = animationXML[Activity].Time;
        for (int j = 0; j < jointsXML.Count; j++)
        {
            if (animationXML[Activity].Initial == jointsXML[j].Id)
            {
                for (int k = 0; k < JointsNumber; k++)
                {
                    if (jointsXML[j].Name.CompareTo(JointsNames[k]) == 0)
                    {
                        skeleton[k].initialX = jointsXML[j].AxisX;
                        skeleton[k].initialY = jointsXML[j].AxisY;
                        skeleton[k].initialZ = jointsXML[j].AxisZ;
                    }
                    // Debug.Log("X:"+jointsXML[j].AxisX);
                    /*   MoveJointAbsolute(skeleton[k].Joint, skeleton[k].initialX+SkeletonInitial[k, 0], 
                                                            skeleton[k].initialY+SkeletonInitial[k, 1], 
                                                            skeleton[k].initialZ+SkeletonInitial[k, 2]);
                   */
  /*              }
            }
            if (animationXML[Activity].Final == jointsXML[j].Id)
            {
                for (int k = 0; k < JointsNumber; k++)
                {
                    if (jointsXML[j].Name.CompareTo(JointsNames[k]) == 0)
                    {
                        skeleton[k].FinalX = jointsXML[j].AxisX;
                        skeleton[k].FinalY = jointsXML[j].AxisY;
                        skeleton[k].FinalZ = jointsXML[j].AxisZ;
                    }
                }
            }
        }
        for (int k = 0; k < JointsNumber; k++)
        {
            skeleton[k].DeltaX = (CalculateAngulo(JointsNames[k], skeleton[k].initialX, skeleton[k].FinalX) / steps);
            skeleton[k].DeltaY = (CalculateAngulo(JointsNames[k], skeleton[k].initialY, skeleton[k].FinalY) / steps);
            skeleton[k].DeltaZ = (CalculateAngulo(JointsNames[k], skeleton[k].initialZ, skeleton[k].FinalZ) / steps);
            //if (k == 4) { Debug.Log(JointsNames[k] + "(" + skeleton[k].initialX + "," + skeleton[k].initialY + "," + skeleton[k].initialZ + ")-("+ skeleton[k].DeltaX+","+ skeleton[k].DeltaY+","+ skeleton[k].DeltaZ+")"); }

        }
    }


    void Start()
    {

    }

    void LateUpdate()
    {
        if (steps > 0)
        {
            steps = steps - 1;
        }
        if (steps == 0)
        {
            for (int i = 0; i < JointsNumber; i++)
            {
                skeleton[i].DeltaX = 0f;
                skeleton[i].DeltaY = 0f;
                skeleton[i].DeltaZ = 0f;
            }
            if (active == true)
            {
                active = false;
                if (actividad < animationXML.Count - 1)
                {
                    actividad++;
                    for (int i = 0; i < JointsNumber; i++)//Initialize values of the animation joints
                    {
                        skeleton[i].initialX = skeleton[i].FinalX;
                        skeleton[i].initialY = skeleton[i].FinalY;
                        skeleton[i].initialZ = skeleton[i].FinalZ;
                        //skeleton[i].initialY = 0.0f; skeleton[i].initialZ = 0.0f;
                        skeleton[i].DeltaX = 0.0f;
                        skeleton[i].DeltaY = 0.0f;
                        skeleton[i].DeltaZ = 0.0f;
                    }
                    animacion(actividad);
                }
            }
        }
        for (int i = 0; i < 25; i++)
        {
            MoveJoints(skeleton[i].Joint, skeleton[i].DeltaX,
                                             skeleton[i].DeltaY,
                                             skeleton[i].DeltaZ);
        }
    }
    public void MoveJoints(Transform joint, float XAxis, float YAxis, float ZAxis)
    {
        joint.Rotate(new Vector3(XAxis, YAxis, ZAxis));
    }
    public void MoveJointAbsolute(Transform joint, float XAxis, float YAxis, float ZAxis)
    {
        joint.transform.localEulerAngles = new Vector3(XAxis, YAxis, ZAxis);
    }

    public float ValidateAngle(float Angle)
    {
        // if (Angle == 0) { Angle = 360; }
        while (Angle < 0.0f) { Angle = Angle + 360; }
        while (Angle > 360.0f) { Angle = Angle - 360; }
        return (Angle);
    }
    public float Distance(string Name, float AngleInitial, float AngleFinal)
    {
        float Angle = 0;
        int direccion = 0;
        if ((Name == "SpineBase") || (Name == "SpineMid") || (Name == "Neck") || (Name == "Head") || (Name == "ShoulderLeft") || (Name == "ElbowRight") || (Name == "WristLeft") || (Name == "HandLeft") ||
             (Name == "ElbowRight") || (Name == "HandRight") || (Name == "HipLeft") || (Name == "HipRight") || (Name == "KneeLeft") || (Name == "AnkleLeft") || (Name == "KneeRight") || (Name == "AnkleRight") || (Name == "WristRight") || (Name == "SpineShoulder") || (Name == "AvatarSkeleton")
             )
        {
            if ((AngleInitial == 0) && (AngleFinal > 180)) { AngleInitial = 360; }
            if ((AngleFinal == 0) && (AngleInitial > 180)) { AngleFinal = 360; }
            if (AngleFinal > AngleInitial) { Angle = Math.Abs(AngleFinal - AngleInitial); direccion = -1; }
            if (AngleFinal < AngleInitial) { Angle = Math.Abs(AngleInitial - AngleFinal); direccion = 1; }
            Angle = Angle * direccion;
            if (Angle > 180) { Angle = (Angle - 360); }
            if (Angle < 180) { Angle = ((Angle) * (-1)); }

        }
        if ((Name == "ShoulderRight"))
        {
            if (AngleFinal > AngleInitial) { Angle = Math.Abs(AngleFinal - AngleInitial); direccion = 1; }
            if (AngleFinal < AngleInitial) { Angle = Math.Abs(AngleInitial - AngleFinal); direccion = -1; }

            if ((AngleInitial > AngleFinal) && (Angle < 180)) { direccion = 1; }
            if ((AngleInitial < AngleFinal) && (Angle < 180)) { direccion = -1; }
            if (Angle > 180) { Angle = Math.Abs(Angle - 360); }
            Angle = Angle * direccion;
            // Debug.Log(Name + "(" + AngleInitial + "," + AngleFinal + "," + Angle +","+ direccion + ")");
        }

        return (Angle);
    }
    public float CalculateAngulo(string Name, float AngleInitial, float AngleFinal)
    {
        //   Debug.Log("Initial(" + AngleInitial + "," + AngleFinal + ")");
        AngleInitial = ValidateAngle(AngleInitial);
        AngleFinal = ValidateAngle(AngleFinal);
        // Debug.Log("Initial(" + AngleInitial + "," + AngleFinal + ")");
        return Distance(Name, AngleInitial, AngleFinal);
    }

    public List<Joint> discretizacion(List<Joint> lista)
    {
        var a = new HashSet<Joint>(lista);
        List<Joint> n = new List<Joint>();
        foreach (Joint m in a) { n.Add(m); }
        return n;
    }
    public List<Animation> discretizacionAnimation(List<Animation> lista)
    {
        var a = new HashSet<Animation>(lista);
        List<Animation> n = new List<Animation>();
        foreach (Animation m in a) { n.Add(m); }
        return n;
    }
    // Update is called once per frame
    void Update() { }
}
*/