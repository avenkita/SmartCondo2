﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic; //this is where the List<T>() class comes from
using System.Xml;

public class ReadWalls : MonoBehaviour {
    public static List<Wall> ListofWalls = new List<Wall>();


    void Start() {
        ListofWalls = getWalls();

        GameObject mycube = Resources.Load("Wallprefab") as GameObject;
        for (int wallnumber = 0; wallnumber < ListofWalls.Count; wallnumber++) { 
            string currentname = ListofWalls[wallnumber].Name;
            GameObject go = Instantiate(mycube);
            go.transform.position = new Vector3(ListofWalls[wallnumber].PositionX, 1.445f, ListofWalls[wallnumber].PositionZ);
            go.transform.localScale = new Vector3(0.1f, 2.573039f, ListofWalls[wallnumber].ScaleZ);
            go.transform.Rotate(0f, ListofWalls[wallnumber].RotateY, 0f);
            go.name = currentname;
        }
    }
    public static void ReadWallsXML()
    {
        //Load
        TextAsset textXML = (TextAsset)Resources.Load("Walls", typeof(TextAsset));
        XmlDocument xml = new XmlDocument();
        xml.LoadXml(textXML.text);
        XmlNodeList transformList = xml.GetElementsByTagName("Walls");


        foreach (XmlNode transformInfo in transformList)
        {
            XmlNodeList transformcontent = transformInfo.ChildNodes;
            foreach (XmlNode transformItems in transformcontent)
            {
                XmlNodeList transformcontent2 = transformItems.ChildNodes;
                Wall w = new Wall();
                foreach (XmlNode transformItems2 in transformcontent2)
                {
                    if (transformItems2.Name == "Name") { w.Name = transformItems2.InnerText; }
                    if (transformItems2.Name == "PositionX") { w.PositionX = float.Parse(transformItems2.InnerText); }
                    if (transformItems2.Name == "PositionZ") { w.PositionZ = float.Parse(transformItems2.InnerText); }
                    if (transformItems2.Name == "ScaleZ") { w.ScaleZ = float.Parse(transformItems2.InnerText); }
                    if (transformItems2.Name == "RotateY") { w.RotateY = float.Parse(transformItems2.InnerText); }
                    
                }
                ListofWalls.Add(w);
            }
        } 
    }

    
    public static List<Wall> getWalls()
    {
        ReadWallsXML();
        return ListofWalls;
    }

    
    // Update is called once per frame
    void Update() { }
}
