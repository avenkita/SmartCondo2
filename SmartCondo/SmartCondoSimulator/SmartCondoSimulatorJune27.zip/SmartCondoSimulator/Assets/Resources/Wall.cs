﻿using System.Xml;
using System.Xml.Serialization;

public class Wall
{
    public string Name { set; get; }
    public float PositionX { set; get; }
    // PositionY is always 1.445
    public float PositionZ { set; get; }
    // ScaleX is always 0.1
    // ScaleY is always 2.573039
    public float ScaleZ { set; get; }
    // RotateX is always 0
    public float RotateY { set; get; }
    // RotateZ is always 0
}